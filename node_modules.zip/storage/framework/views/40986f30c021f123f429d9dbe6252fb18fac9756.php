

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Staff</li>
      </ol>
    </nav>
    <div class="row">
      
        <?php if(count($staffs) > 0): ?>
            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card shadow-sm mb-2">
                      
                      <div class="card-body">
                        <img src="storage/cover_images/<?php echo e($staff->image); ?>" alt="" class="rounded-circle img-thumbnail">
                        <h4 class="text-secondary"><?php echo e($staff->empname); ?></h4>
                        <h6><?php echo e($staff->position); ?></h6>
                        <p>Join On: <?php echo e($staff->created_at); ?></p>
                      </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kurafrica\resources\views/staffs/index.blade.php ENDPATH**/ ?>