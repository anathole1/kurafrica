

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
       <div class="row">
           <div class="col-sm-12">
               <div class="table-responsive">
                <table class="table">
                    <thead class="bg-main">
                      <tr>
                        <th scope="col">P. Name <br> Contact</th>
                        
                        <th scope="col">P. Info</th>
                        <th scope="col">PAT / BTC</th>
                        <th scope="col">C. Name / School</th>
                        <th scope="col">D.O.B</th>
                        <th scope="col">Category</th>
                        <th scope="col">Availability</th>
                        <th scope="col">Program Time</th>
                        <th scope="col">Exceptions</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php if(count($applications) > 0): ?>
                            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($application->pname); ?> / <?php echo e($application->title); ?> <br><?php echo e($application->tel); ?></th>
                                    
                                    <td><?php echo e($application->address); ?><br><?php echo e($application->email); ?></td>
                                    <td><?php echo e($application->p_av_time); ?><br><?php echo e($application->b_time_call); ?></td>
                                    <td><?php echo e($application->child_name); ?> / <?php echo e($application->c_school); ?></td>
                                    <td><?php echo e($application->dob); ?></td>   
                                    <td><?php echo e($application->facility); ?></td>   
                                    <td><?php echo e($application->availability); ?></td>   
                                    <td><?php echo e($application->program_time); ?></td>   
                                    <td><?php echo e($application->expections); ?></td>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                  </table>
               </div>
            
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kurafrica\resources\views/mentee_application/index.blade.php ENDPATH**/ ?>