

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">About</li>
        </ol>
      </nav>
    <div class="row ">
        <div class="col-sm-4">
            <img src="/storage/images/eductinal.jpg" alt="" class="img-fluid">
            
            <h3>VISION</h3>
            <p> Foundation of the bright future is the visualized children
            Mentoring at least 5,000,000 children in whole Africa in 10 years ahead and encouraging parents to participate in this program in order to help their children to get bright future.
            </p>
            <h3>MISSION</h3>
            <p>
            Helping unnoticed talented and dreamed children and get supported through home based mentorship
            Home Based Mentorship Initiative (HBMI) is social enterprise that provides professional coaching packages with identifying, guiding and supporting the unnoticed talents and dreams of children in nursery, primary and high school in Ordinary level.
            </p> 
        </div>
        <div class="col-sm-8">
            <img src="/storage/images/krafrica.png" alt="" class="img-fluid d-md-none">
            <h2>Background</h2>
            <p>“Mentoring is a brain to pick, an ear to listen, and a push in the right direction” John Crosby, “Tell me and I forget, teach me and I may remember, involve  me and I learn” Benjamin Franklin “Children must be taught how to think, not what to think.” Margaret Mead. 
            </p>
            <p>is very helpful to the children to be facilitated at home through children supporting program called home based mentoring program (HBMP) designed with the set of tools, resources, and practical training sessions for children to develop their thinking capacity, sticking and stay focused on their dream and moreover that it enhances their learning quality, competence, performance and effectiveness in their studies through self-learning (coaching).</p>
            <p> These HBMP and online mentoring program allow children to get supported through the different programmatic packages the one is coaching and listening to child/children patiently and help to find a solution to their problems. We advise and guide them to the path of their dreams in childhood and encouraging them to be who they are and know their worth and value. They get inspiration from their role models and helping them to set goals and stay determined and focused on their goals. We are full of empathy, great listeners, and advisors and communicating well which is why we believe that the children who have passed through in our program, they get changed and becoming smart tremendously and decide wisely.</p>
        </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anathole\kurafrica\resources\views/pages/about.blade.php ENDPATH**/ ?>