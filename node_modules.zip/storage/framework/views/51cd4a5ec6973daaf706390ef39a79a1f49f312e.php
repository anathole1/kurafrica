

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">E-library</li>
        </ol>
    </nav>
       <div class="row">
           <div class="col-12">
               <div class="alert alert-danger">Not yet registered on any course please apply via link below</div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kurafrica\resources\views/pages/elibrary.blade.php ENDPATH**/ ?>