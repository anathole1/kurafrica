

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Schorlaship</li>
            </ol>
        </nav>
        
        <div class="row">
            <div class="col-12">
                <div class="alert alert-danger">
                    No scharlaship available now
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anathole\kurafrica\resources\views/pages/schorlaship.blade.php ENDPATH**/ ?>