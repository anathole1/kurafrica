@extends('layouts.app')

@section('content')
    <p class="bg-danger">Under construction</p>
@endsection