

<?php $__env->startSection('content'); ?>
    <?php echo e(config('app.name')); ?>

    <h1>index</h1>
    <p>This is Laravel Tutorial series</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anathole\kurafrica\resources\views/pages/index.blade.php ENDPATH**/ ?>