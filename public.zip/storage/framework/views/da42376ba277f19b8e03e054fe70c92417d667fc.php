

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Home-Online Coaching</li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-12">
                <h2 class="text-center">Supporting program packages</h2>
            </div>
            <div class="col-sm-6">
                <img src="/storage/images/online-education.jpg" style="height: 300px; object-fit:cover" alt="" class="img-thumbnail">
                <h3>1. Online based coaching</h3>
                <p>This upskills takeaway are served via zoom by practical coaching sessions.</p>
                <div class="col-12 text-center ">
                    <h5 class="text-center"><b>Period: one month</b></h5>
                    <h5 class="text-center"><b>Price: 20$ USD</b></h5>
                    <a href="/apply/create" class="btn btn-outline-primary">Apply Now</a>
                </div>
            </div>
            <div class="col-sm-6">
                <img src="/storage/images/coaching.jpg" style="height: 300px;object-fit:cover" alt="" class="img-thumbnail">
                <h3>2. Home based Coaching</h3>
                <p>This upskills takeaway are served at home by practical coaching sessions.</p>
                <div class="col-12 text-center ">
                    <h5 class="text-center"><b>Period: one month</b></h5>
                    <h5 class="text-center"><b>Price: 50$ USD</b></h5>
                    <a href="/apply/create" class="btn btn-outline-primary">Apply Now</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <p ><b>Benefities:</b></p>
                <div>
                    <ol>
                        <li>Excellence performance in class</li>
                        <li>Being competent in all courses</li>
                        <li>Being productive in all possible fields</li>
                        <li>Getting all possible facilities  in   home self learning</li>
                        <li>Getting expert facilitators anytime,anywhere</li>
                    </ol>
                </div>
            </div>
            <div class="col-sm-6">
                <p><b>Online or Home based Coaching packages</b></p>
                <p>These upskill packages are served to children continuously once agreed  or it can last one year  and renewed depends on  willing  of child/children and their parents</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anathole\kurafrica\resources\views/pages/hoc.blade.php ENDPATH**/ ?>