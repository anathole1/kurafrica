

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Create Staff</li>
    </ol>
  </nav>
  <div class="row">
    <div class="col-12 ">

      <?php echo Form::open(['action' => 'App\Http\Controllers\StaffController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

          <div class="form-group">
              <?php echo e(Form::label('name','Name:')); ?>

              <?php echo e(Form::text('name','',['class' => 'form-control', 'placeholder' => 'Enter Names here'])); ?>

          </div>
          <div class="form-group">
          <?php echo e(Form::label('post','Position:')); ?>

              <?php echo e(Form::text('post', '',['class' => 'form-control','placeholder' => 'Enter your Position'])); ?>

          </div>
          <div class="form-group">
              <?php echo e(Form::file('image')); ?>

          </div>
              <?php echo e(Form::submit('Submit',['class' => 'btn btn-primary'])); ?>

      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kurafrica\resources\views/staffs/create.blade.php ENDPATH**/ ?>