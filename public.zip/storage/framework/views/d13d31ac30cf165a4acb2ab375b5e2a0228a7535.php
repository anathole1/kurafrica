
<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
       <div class="row">
           <div class="col-md-12">
               <div class="table-responsive">
                   <table class="table">
                       <thead class="table-dark">
                            <th>Donor</th>
                            <th>Email</th>
                            <th>Phone N<sup>o</sup></th>
                            <th>Donation</th>
                            <th>Date</th>
                       </thead>
                       <tbody>
                            <?php if(count($donates) > 0 ): ?>
                                <?php $__currentLoopData = $donates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($donate->names); ?></td>
                                        <td><?php echo e($donate->email); ?></td>
                                        <td><?php echo e($donate->tel); ?></td>
                                        <td><?php echo e($donate->type); ?></td>
                                        <td><?php echo e($donate->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                       </tbody>
                   </table>
               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kurafrica\resources\views/donate/index.blade.php ENDPATH**/ ?>