@extends('layouts.app')

@section('content')

<div class="container">
    swal("Hello world!");
</div>
@endsection